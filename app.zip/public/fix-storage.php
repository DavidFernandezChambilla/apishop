<?php

/**
 * Script para reparar el enlace simbólico del storage en entornos de CPanel
 * sin acceso a terminal (SSH).
 */

$publicStoragePath = __DIR__ . '/storage';
$targetStoragePath = __DIR__ . '/../storage/app/public';

clearstatcache();
echo "<h2>Reparador de Storage para CPanel</h2>";
echo "Ruta buscada: $publicStoragePath <br>";

// 1. Intentar detectar qué hay exactamente ahí
if (is_link($publicStoragePath)) {
    echo "Se detectó un enlace simbólico. Intentando refrescarlo...<br>";
    unlink($publicStoragePath);
} elseif (is_dir($publicStoragePath)) {
    echo "<b>Atención:</b> Se detectó que 'public/storage' es una CARPETA real.<br>";
    echo "Intentando renombrarla para despejar el camino...<br>";
    if (rename($publicStoragePath, $publicStoragePath . '_backup_' . time())) {
        echo "Carpeta renombrada exitosamente.<br>";
    } else {
        echo "<span style='color:red;'>No se pudo mover la carpeta. Por favor, asegúrate de borrarla o renombrarla manualmente en CPanel.</span><br>";
        exit;
    }
} elseif (file_exists($publicStoragePath)) {
    echo "Se detectó un ARCHIVO con el nombre 'storage'. Borrándolo...<br>";
    unlink($publicStoragePath);
}

// 2. Crear el enlace simbólico
if (symlink($targetStoragePath, $publicStoragePath)) {
    echo "<span style='color:green; font-size: 20px;'><b>¡ÉXITO!</b> El enlace simbólico ha sido creado correctamente.</span><br>";
    echo "Ahora tus imágenes deberían ser visibles.<br>";
} else {
    $error = error_get_last();
    echo "<span style='color:red;'>Error al crear el enlace: " . ($error['message'] ?? 'Desconocido') . "</span><br>";
    echo "Asegúrate de que la ruta de origen existe: $targetStoragePath<br>";
}

echo "<br><hr><a href='/'>Ir a la web</a>";
